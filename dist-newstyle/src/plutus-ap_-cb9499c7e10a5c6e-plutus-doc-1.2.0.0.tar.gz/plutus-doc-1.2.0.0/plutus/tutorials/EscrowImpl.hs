{-# LANGUAGE DataKinds            #-}
{-# LANGUAGE DeriveAnyClass       #-}
{-# LANGUAGE DeriveGeneric        #-}
{-# LANGUAGE DerivingStrategies   #-}
{-# LANGUAGE FlexibleContexts     #-}
{-# LANGUAGE LambdaCase           #-}
{-# LANGUAGE NamedFieldPuns       #-}
{-# LANGUAGE NoImplicitPrelude    #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE TemplateHaskell      #-}
{-# LANGUAGE TypeApplications     #-}
{-# LANGUAGE TypeFamilies         #-}
{-# LANGUAGE TypeOperators        #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -fplugin-opt PlutusTx.Plugin:debug-context #-}
{- START OPTIONS_GHC -}
{-# OPTIONS_GHC -g -fplugin-opt PlutusTx.Plugin:coverage-all #-}
{- END OPTIONS_GHC -}
-- | A general-purpose escrow contract in Plutus
module EscrowImpl(
    -- $escrow
    Escrow
    , EscrowError(..)
    , AsEscrowError(..)
    , EscrowParams(..)
    , EscrowTarget(..)
    , payToScriptTarget
    , payToPaymentPubKeyTarget
    , targetTotal
    , escrowContract
    , payRedeemRefund
    , typedValidator
    -- * Actions
    , pay
    , payEp
    , redeem
    , redeemEp
    , refund
    , refundEp
    , RedeemFailReason(..)
    , RedeemSuccess(..)
    , RefundSuccess(..)
    , EscrowSchema
    -- * Exposed for test endpoints
    , Action(..)
    -- * Coverage
    , covIdx
    ) where

import Control.Lens (_1, has, makeClassyPrisms, only, review, view)
import Control.Monad (Monad ((>>)), void)
import Control.Monad.Error.Lens (throwing)
import Data.Aeson (FromJSON, ToJSON)
import GHC.Generics (Generic)

import Ledger (POSIXTime, PaymentPubKeyHash (unPaymentPubKeyHash), ScriptContext (ScriptContext, scriptContextTxInfo),
               TxId, getCardanoTxId, interval, scriptOutputsAt, txSignedBy, valuePaidTo)
import Ledger qualified
import Ledger.Interval (after, before, from)
import Ledger.Tx qualified as Tx
import Ledger.Tx.Constraints (TxConstraints)
import Ledger.Tx.Constraints qualified as Constraints
import Ledger.Tx.Constraints.ValidityInterval qualified as Interval
import Ledger.Typed.Scripts (TypedValidator)
import Ledger.Typed.Scripts qualified as Scripts
import Plutus.Script.Utils.Scripts qualified as Scripts
import Plutus.Script.Utils.V1.Scripts qualified as Scripts
import Plutus.Script.Utils.Value (Value, geq, lt)
import Plutus.V1.Ledger.Api (Datum (Datum), DatumHash, ValidatorHash)
import Plutus.V1.Ledger.Contexts (ScriptContext (ScriptContext, scriptContextTxInfo), TxInfo (txInfoValidRange))

import Cardano.Node.Emulator.Params qualified as Params
import Plutus.Contract (AsContractError (_ContractError), Contract, ContractError, Endpoint, HasEndpoint, Promise,
                        adjustUnbalancedTx, awaitTime, currentNodeClientTimeRange, currentTime, endpoint, getParams,
                        mapError, mkTxConstraints, ownFirstPaymentPubKeyHash, promiseMap, selectList,
                        submitUnbalancedTx, type (.\/), utxosAt, waitNSlots)
import PlutusTx qualified
{- START imports -}
import PlutusTx.Code qualified as PlutusTx
import PlutusTx.Coverage qualified as PlutusTx
{- END imports -}
import PlutusTx.Prelude (Bool (False), Either (Left, Right), all, either, foldl, fst, id, mempty, traceIfFalse, ($),
                         (&&), (+), (-), (.), (<$>), (==), (>=))

import Prelude (Semigroup ((<>)), foldMap, (>>=))
import Prelude qualified as Haskell

type EscrowSchema =
        Endpoint "pay-escrow" Value
        .\/ Endpoint "redeem-escrow" ()
        .\/ Endpoint "refund-escrow" ()

data RedeemFailReason = DeadlinePassed | NotEnoughFundsAtAddress
    deriving stock (Haskell.Eq, Haskell.Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

data EscrowError =
    RedeemFailed RedeemFailReason
    | RefundFailed
    | EContractError ContractError
    deriving stock (Haskell.Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

makeClassyPrisms ''EscrowError

instance AsContractError EscrowError where
    _ContractError = _EContractError

-- $escrow
-- The escrow contract implements the exchange of value between multiple
-- parties. It is defined by a list of targets (public keys and script
-- addresses, each associated with a value). It works similar to the
-- crowdfunding contract in that the contributions can be made independently,
-- and the funds can be unlocked only by a transaction that pays the correct
-- amount to each target. A refund is possible if the outputs locked by the
-- contract have not been spent by the deadline. (Compared to the crowdfunding
-- contract, the refund policy is simpler because here because there is no
-- "collection period" during which the outputs may be spent after the deadline
-- has passed. This is because we're assuming that the participants in the
-- escrow contract will make their deposits as quickly as possible after
-- agreeing on a deal)
--
-- The contract supports two modes of operation, manual and automatic. In
-- manual mode, all actions are driven by endpoints that exposed via 'payEp'
-- 'redeemEp' and 'refundEp'. In automatic mode, the 'pay', 'redeem' and
-- 'refund'actions start immediately. This mode is useful when the escrow is
-- called from within another contract, for example during setup (collection of
-- the initial deposits).

-- | Defines where the money should go. Usually we have `d = Datum` (when
--   defining `EscrowTarget` values in off-chain code). Sometimes we have
--   `d = DatumHash` (when checking the hashes in on-chain code)
data EscrowTarget d =
    PaymentPubKeyTarget PaymentPubKeyHash Value
    | ScriptTarget ValidatorHash d Value
    deriving (Haskell.Functor)

PlutusTx.makeLift ''EscrowTarget

-- | An 'EscrowTarget' that pays the value to a public key address.
payToPaymentPubKeyTarget :: PaymentPubKeyHash -> Value -> EscrowTarget d
payToPaymentPubKeyTarget = PaymentPubKeyTarget

-- | An 'EscrowTarget' that pays the value to a script address, with the
--   given data script.
payToScriptTarget :: ValidatorHash -> Datum -> Value -> EscrowTarget Datum
payToScriptTarget = ScriptTarget

-- | Definition of an escrow contract, consisting of a deadline and a list of targets
data EscrowParams d =
    EscrowParams
        { escrowDeadline :: POSIXTime
        -- ^ Latest point at which the outputs may be spent.
        , escrowTargets  :: [EscrowTarget d]
        -- ^ Where the money should go. For each target, the contract checks that
        --   the output 'mkTxOutput' of the target is present in the spending
        --   transaction.
        } deriving (Haskell.Functor)

PlutusTx.makeLift ''EscrowParams

-- | The total 'Value' that must be paid into the escrow contract
--   before it can be unlocked
targetTotal :: EscrowParams d -> Value
targetTotal = foldl (\vl tgt -> vl + targetValue tgt) mempty . escrowTargets

-- | The 'Value' specified by an 'EscrowTarget'
targetValue :: EscrowTarget d -> Value
targetValue = \case
    PaymentPubKeyTarget _ vl -> vl
    ScriptTarget _ _ vl      -> vl

-- | Create a 'Ledger.TxOut' value for the target
mkTx :: EscrowTarget Datum -> TxConstraints Action PaymentPubKeyHash
mkTx = \case
    PaymentPubKeyTarget pkh vl ->
        Constraints.mustPayToPubKey pkh vl
    ScriptTarget vs ds vl ->
        Constraints.mustPayToOtherScriptWithDatumHash vs ds vl

data Action = Redeem | Refund

data Escrow
instance Scripts.ValidatorTypes Escrow where
    type instance RedeemerType Escrow = Action
    type instance DatumType Escrow = PaymentPubKeyHash

PlutusTx.unstableMakeIsData ''Action
PlutusTx.makeLift ''Action

{-# INLINABLE meetsTarget #-}
-- | @ptx `meetsTarget` tgt@ if @ptx@ pays at least @targetValue tgt@ to the
--   target address.
--
--   The reason why this does not require the target amount to be equal
--   to the actual amount is to enable any excess funds consumed by the
--   spending transaction to be paid to target addresses. This may happen if
--   the target address is also used as a change address for the spending
--   transaction, and allowing the target to be exceed prevents outsiders from
--   poisoning the contract by adding arbitrary outputs to the script address.
meetsTarget :: TxInfo -> EscrowTarget DatumHash -> Bool
meetsTarget ptx = \case
    PaymentPubKeyTarget pkh vl ->
        valuePaidTo ptx (unPaymentPubKeyHash pkh) `geq` vl
    ScriptTarget validatorHash dataValue vl ->
        case scriptOutputsAt validatorHash ptx of
            [(dataValue', vl')] ->
                traceIfFalse "dataValue" (dataValue' == dataValue)
                && traceIfFalse "value" (vl' `geq` vl)
            _ -> False

{-# INLINABLE validate #-}
validate :: EscrowParams DatumHash -> PaymentPubKeyHash -> Action -> ScriptContext -> Bool
validate EscrowParams{escrowDeadline, escrowTargets} contributor action ScriptContext{scriptContextTxInfo} =
    case action of
        Redeem ->
            traceIfFalse "escrowDeadline-after" (escrowDeadline `after` txInfoValidRange scriptContextTxInfo)
            && traceIfFalse "meetsTarget" (all (meetsTarget scriptContextTxInfo) escrowTargets)
        Refund ->
            traceIfFalse "escrowDeadline-before" ((escrowDeadline - 1) `before` txInfoValidRange scriptContextTxInfo)
            && traceIfFalse "txSignedBy" (scriptContextTxInfo `txSignedBy` unPaymentPubKeyHash contributor)

{- START typedValidator -}
typedValidator :: EscrowParams Datum -> Scripts.TypedValidator Escrow
typedValidator escrow = go (Haskell.fmap Scripts.datumHash escrow) where
    go = Scripts.mkTypedValidatorParam @Escrow
        $$(PlutusTx.compile [|| validate ||])
        $$(PlutusTx.compile [|| wrap ||])
    wrap = Scripts.mkUntypedValidator
{- END typedValidator -}
escrowContract
    :: EscrowParams Datum
    -> Contract () EscrowSchema EscrowError ()
escrowContract escrow =
    let inst = typedValidator escrow
        payAndRefund = endpoint @"pay-escrow" $ \vl -> do
            _ <- pay inst escrow vl
            _ <- awaitTime $ escrowDeadline escrow
            refund inst escrow
    in selectList
        [ void payAndRefund
        , void $ redeemEp escrow
        ]

-- | 'pay' with an endpoint that gets the owner's public key and the
--   contribution.
payEp ::
    forall w s e.
    ( HasEndpoint "pay-escrow" Value s
    , AsEscrowError e
    )
    => EscrowParams Datum
    -> Promise w s e TxId
payEp escrow = promiseMap
    (mapError (review _EContractError))
    (endpoint @"pay-escrow" $ pay (typedValidator escrow) escrow)

-- | Pay some money into the escrow contract.
pay ::
    forall w s e.
    ( AsContractError e
    )
    => TypedValidator Escrow
    -- ^ The instance
    -> EscrowParams Datum
    -- ^ The escrow contract
    -> Value
    -- ^ How much money to pay in
    -> Contract w s e TxId
pay inst escrow vl = do
    pk <- ownFirstPaymentPubKeyHash
    let tx = Constraints.mustPayToTheScriptWithDatumHash pk vl
          <> Constraints.mustValidateInTimeRange (Interval.interval 1 (1 + escrowDeadline escrow))
    utx <- mkTxConstraints (Constraints.typedValidatorLookups inst) tx >>= adjustUnbalancedTx
    getCardanoTxId <$> submitUnbalancedTx utx

newtype RedeemSuccess = RedeemSuccess TxId
    deriving (Haskell.Eq, Haskell.Show)

-- | 'redeem' with an endpoint.
redeemEp ::
    forall w s e.
    ( HasEndpoint "redeem-escrow" () s
    , AsEscrowError e
    )
    => EscrowParams Datum
    -> Promise w s e RedeemSuccess
redeemEp escrow = promiseMap
    (mapError (review _EscrowError))
    (endpoint @"redeem-escrow" $ \() -> redeem (typedValidator escrow) escrow)

-- | Redeem all outputs at the contract address using a transaction that
--   has all the outputs defined in the contract's list of targets.
redeem ::
    forall w s e.
    ( AsEscrowError e
    )
    => TypedValidator Escrow
    -> EscrowParams Datum
    -> Contract w s e RedeemSuccess
redeem inst escrow = mapError (review _EscrowError) $ do
    networkId <- Params.pNetworkId <$> getParams
    let addr = Scripts.validatorCardanoAddress networkId inst
    current <- Haskell.snd <$> currentNodeClientTimeRange
    unspentOutputs <- utxosAt addr
    let
        valRange = Interval.lessThan $ escrowDeadline escrow
        tx = Constraints.collectFromTheScript unspentOutputs Redeem
                <> foldMap mkTx (escrowTargets escrow)
                <> Constraints.mustValidateInTimeRange valRange
    if current >= escrowDeadline escrow
    then throwing _RedeemFailed DeadlinePassed
    else if foldMap Tx.decoratedTxOutPlutusValue unspentOutputs `lt` targetTotal escrow
         then throwing _RedeemFailed NotEnoughFundsAtAddress
         else do
           utx <- mkTxConstraints ( Constraints.typedValidatorLookups inst
                                 <> Constraints.unspentOutputs unspentOutputs
                                  ) tx >>= adjustUnbalancedTx
           RedeemSuccess . getCardanoTxId <$> submitUnbalancedTx utx

newtype RefundSuccess = RefundSuccess TxId
    deriving newtype (Haskell.Eq, Haskell.Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- | 'refund' with an endpoint.
refundEp ::
    forall w s.
    ( HasEndpoint "refund-escrow" () s
    )
    => EscrowParams Datum
    -> Promise w s EscrowError RefundSuccess
refundEp escrow = endpoint @"refund-escrow" $ \() -> refund (typedValidator escrow) escrow

-- | Claim a refund of the contribution.
refund ::
    forall w s.
    TypedValidator Escrow
    -> EscrowParams Datum
    -> Contract w s EscrowError RefundSuccess
refund inst escrow = do
    pk <- ownFirstPaymentPubKeyHash
    networkId <- Params.pNetworkId <$> getParams
    unspentOutputs <- utxosAt (Scripts.validatorCardanoAddress networkId inst)
    let pkh = Scripts.datumHash $ Datum $ PlutusTx.toBuiltinData pk
    let flt _ ciTxOut = has (Tx.decoratedTxOutScriptDatum . _1 . only pkh) ciTxOut
        tx' = Constraints.collectFromTheScriptFilter flt unspentOutputs Refund
                <> Constraints.mustValidateInTimeRange (Interval.from (Haskell.succ $ escrowDeadline escrow))
    if Constraints.modifiesUtxoSet tx'
    then do
        utx <- mkTxConstraints ( Constraints.typedValidatorLookups inst
                              <> Constraints.unspentOutputs unspentOutputs
                               ) tx' >>= adjustUnbalancedTx
        RefundSuccess . getCardanoTxId <$> submitUnbalancedTx utx
    else throwing _RefundFailed ()

-- | Pay some money into the escrow contract. Then release all funds to their
--   specified targets if enough funds were deposited before the deadline,
--   or reclaim the contribution if the goal has not been met.
payRedeemRefund ::
    forall w s.
    EscrowParams Datum
    -> Value
    -> Contract w s EscrowError (Either RefundSuccess RedeemSuccess)
payRedeemRefund params vl = do
    networkId <- Params.pNetworkId <$> getParams
    let inst = typedValidator params
        go = do
            cur <- utxosAt (Scripts.validatorCardanoAddress networkId inst)
            let presentVal = foldMap Tx.decoratedTxOutPlutusValue cur
            if presentVal `geq` targetTotal params
                then Right <$> redeem inst params
                else do
                    time <- Haskell.snd <$> currentNodeClientTimeRange
                    if time >= escrowDeadline params
                        then Left <$> refund inst params
                        else waitNSlots 1 >> go
    -- Pay the value 'vl' into the contract
    void $ pay inst params vl
    go

{- START covIdx -}
covIdx :: PlutusTx.CoverageIndex
covIdx = PlutusTx.getCovIdx $$(PlutusTx.compile [|| validate ||])
{- END covIdx -}
